# `data.json`
Fetched from `https://api.fontawesome.com`
```
query {
  release (version: "6.0.0") {icons(license: "free") {id, changes}}
}
```

# `all.js`
Source: `https://fontawesome.com/v6/download` "Free for Web" `js/all.js`

# `shims.json`
_Unused_