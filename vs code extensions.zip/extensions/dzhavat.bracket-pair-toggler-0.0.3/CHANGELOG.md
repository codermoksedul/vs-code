# Changelog

## 0.0.3 - 2023-02-08

### Changed

- Set the minimum supported VS Code version to 1.70.0
- Update dependencies

## 0.0.2 - 2021-11-24

### Added

- Extension icon

## 0.0.1 - 2021-11-20

- Initial release

### Added

Command to toggle global "Bracket Pair Colorization" setting

- Press `Ctrl + Shift + P` (Win, Linux) / `Cmd + Shift + P` (Mac) and search for the `Toggle 'Bracket Pair Colorization'` command.
