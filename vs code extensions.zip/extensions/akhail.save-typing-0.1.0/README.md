# Save typing

Extension for live editing where auto save

## Features

While you typing this extension save.

## Requirements

Nothing

## Known Issues

Nothing

## Release Notes

Users appreciate release notes as you update your extension.

### 1.0.0

Initial release of ...



-----------------------------------------------------------------------------------------------------------
